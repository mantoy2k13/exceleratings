<script src="https://www.gstatic.com/firebasejs/5.6.0/firebase.js"></script>
<script>
  // Initialize Firebase
  var config = {
    apiKey: "AIzaSyATkNlyFL9aj3Y9OZirEZbfcZNtpGLHXjA",
    authDomain: "wellscapelounge-128df.firebaseapp.com",
    databaseURL: "https://wellscapelounge-128df.firebaseio.com",
    projectId: "wellscapelounge-128df",
    storageBucket: "wellscapelounge-128df.appspot.com",
    messagingSenderId: "304769649906"
  };
  firebase.initializeApp(config);
</script>
<?php 
	$this->load->view('admin/firebase-update/firebase-connect'); 
//	pre($action);
?>

<svg class="ldt-blank" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" preserveAspectRatio="xMidYMid">
	<style type="text/css">path,ellipse,circle,rect,polygon,polyline,line { stroke-width: 0; }
		@keyframes ld-fade {
		  0% {
			 opacity: 1;
		  }
		  100% {
			 opacity: 0;
		  }
		}
		@-webkit-keyframes ld-fade {
		  0% {
			 opacity: 1;
		  }
		  100% {
			 opacity: 0;
		  }
		}
		.ld.ld-fade {
		  -webkit-animation: ld-fade 1s infinite linear;
		  animation: ld-fade 1s infinite linear;
		}
		
		text { font-family: Courier New }
	</style>
	<center>
	<g transform="translate(33.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.952381s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">F</text>
	  </g>
	</g><g transform="translate(63.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.904762s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">i</text>
	  </g>
	</g><g transform="translate(93.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.857143s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">r</text>
	  </g>
	</g><g transform="translate(123.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.809524s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">e</text>
	  </g>
	</g><g transform="translate(153.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.761905s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">b</text>
	  </g>
	</g><g transform="translate(183.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.714286s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">a</text>
	  </g>
	</g><g transform="translate(213.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.666667s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">s</text>
	  </g>
	</g><g transform="translate(243.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.619048s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">e</text>
	  </g>
	</g><g transform="translate(273.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.571429s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 8.75px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New"> </text>
	  </g>
	</g><g transform="translate(291 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.52381s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">U</text>
	  </g>
	</g><g transform="translate(321 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.47619s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">p</text>
	  </g>
	</g><g transform="translate(351 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.428571s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">d</text>
	  </g>
	</g><g transform="translate(381 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.380952s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">a</text>
	  </g>
	</g><g transform="translate(411 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.333333s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">t</text>
	  </g>
	</g><g transform="translate(441 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.285714s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">i</text>
	  </g>
	</g><g transform="translate(471 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.238095s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">n</text>
	  </g>
	</g><g transform="translate(501 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.190476s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">g</text>
	  </g>
	</g><g transform="translate(531 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.142857s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 8.75px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New"> </text>
	  </g>
	</g><g transform="translate(548.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.0952381s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">.</text>
	  </g>
	</g><g transform="translate(578.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: -0.047619s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">.</text>
	  </g>
	</g><g transform="translate(608.5 64.6)" style="opacity: 1;">
	  <g style="animation-delay: 0s; animation-duration: 1s; font-size: 50px; animation-direction: normal; transform-origin: 15px 0px 0px;" class="ld ld-fade">
		 <text fill="#4d4f53" style="font-family:Courier New">.</text>
	  </g>
	</g>
	</center>
</svg>

<script>
/*
	function writeUserData(userId, name, email, imageUrl) {
		firebase.database().ref('test/' + userId).set({
			username: name,
			email: email,
			profile_picture : imageUrl
		});
	}
	writeUserData('aa','bb','cc','dd');
*/
	<?php
		if( $for == 'post' ){
			
			if( isset($theItemData->fullScreenSaverFileName) ){
				$theItemData->fullScreenSaverFileName = base_url('uploads/') . $theItemData->fullScreenSaverFileName;
			}
			if( isset($theItemData->trailerScreenSaverFileName) ){
				$theItemData->trailerScreenSaverFileName = base_url('uploads/') . $theItemData->trailerScreenSaverFileName;
			}
			if( isset($theItemData->video_poster) ){
				$theItemData->video_poster = base_url('uploads/') . $theItemData->video_poster;
			}
			
		//	$theItemData->
			if( $action == 'update' ){
	?>
			firebase.database().ref('screensaver_description/' + <?=$theItemData->id?>).set(<?php echo json_encode($theItemData); ?>).then(function(){
				
				<?php 
					$this->session->set_flashdata('success', 'Saved your change ...');
					if( $this->session->flashdata('rdr') ){ ?>
					window.location.replace('<?php echo $this->session->flashdata('rdr'); ?>');
				<?php } ?>
			});
	<?php
			}elseif( $action == 'add' ){
	?>
			firebase.database().ref('screensaver_description/' + <?=$theItemData->id?>).set(<?php echo json_encode($theItemData); ?>).then(function(){
				
				<?php 
					$this->session->set_flashdata('success', 'New Screensaver item added ...');
					if( $this->session->flashdata('rdr') ){ ?>
					window.location.replace('<?php echo $this->session->flashdata('rdr'); ?>');
				<?php } ?>
			});
	<?php
			}elseif( $action == 'delete' ){
	?>
			firebase.database().ref('screensaver_description').child('<?=$theItemData->id?>').remove().then(function(){
				
				<?php 
					$this->session->set_flashdata('success', 'A post item removed ...');
					if( $this->session->flashdata('rdr') ){ ?>
					window.location.replace('<?php echo $this->session->flashdata('rdr'); ?>');
				<?php } ?>
			});
	<?php
			} 
		}elseif( $for == 'category' ){
		//	pre($theItemData);
		//	exit;
			if( isset($theItemData->category_img) ){
				$theItemData->category_img = base_url('uploads/category-img/') . $theItemData->category_img;
			}
			if( $action == 'update' ){
	?>
			firebase.database().ref('screensaver_category/' + <?=$theItemData->id?>).set(<?php echo json_encode($theItemData); ?>).then(function(){
				
				<?php 
					$this->session->set_flashdata('success', 'Saved your change ...');
					if( $this->session->flashdata('rdr') ){ ?>
					window.location.replace('<?php echo $this->session->flashdata('rdr'); ?>');
				<?php } ?>
			});
	<?php 
			}elseif( $action == 'add' ){
	?>
			firebase.database().ref('screensaver_category/' + <?=$theItemData->id?>).set(<?php echo json_encode($theItemData); ?>).then(function(){
				
				<?php 
					$this->session->set_flashdata('success', 'New category item added ...');
					if( $this->session->flashdata('rdr') ){ ?>
					window.location.replace('<?php echo $this->session->flashdata('rdr'); ?>');
				<?php } ?>
			});
	<?php
			}elseif( $action == 'delete' ){
	?>
			firebase.database().ref('screensaver_category').child('<?=$theItemData->id?>').remove().then(function(){
				
				<?php 
					$this->session->set_flashdata('success', 'A category item removed ...');
					if( $this->session->flashdata('rdr') ){ ?>
					window.location.replace('<?php echo $this->session->flashdata('rdr'); ?>');
				<?php } ?>
			});
	<?php
			}
		}
	?>
</script>



