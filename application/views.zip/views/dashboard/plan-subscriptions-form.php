<?php $this->load->view('front/header-pg'); ?>

		 <div class="container">
			
         <?php $this->load->view('dashboard/plan-subscriptions-form-in'); ?>

		 </div>
        
<?php $this->load->view('front/footer-pg');?>