<?php
defined('BASEPATH') OR exit('No direct script access allowed');


$config['protocol'] = 'smtp';
$config['smtp_port'] = '587';
$config['smtp_host'] = 'smtp.sendgrid.net';
$config['smtp_user'] = 'apikey';
$config['smtp_pass'] = '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';