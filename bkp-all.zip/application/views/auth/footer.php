


    <script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/vendor/jquery-2.1.4.min.js"></script>
    <script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/popper.min.js"></script>
    <script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/plugins.js"></script>
    <script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/main.js"></script>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/wow/1.1.2/wow.min.js"></script>
    <script src="<?php echo base_url('/'); ?>assets/dashboard/custom/custom.js"></script>

  
    <script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/lib/data-table/datatables-init.js"></script>
	<script src="<?php echo base_url('/'); ?>assets/dashboard/custom/custom.js"></script>

	<script>
		new WOW().init();
	</script>

</body>
</html>