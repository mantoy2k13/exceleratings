  
</div>
  
	<script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/vendor/jquery-2.1.4.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/dashboard/plugins/wow.min.js"></script>
	<script>
		new WOW().init();
	</script>
	<script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/popper.min.js"></script>
	<script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/plugins.js"></script>
	<script src="<?php echo base_url('/'); ?>assets/dashboard/assets/js/main.js"></script>

	<script src="-bs/Chart.js/2.7.3/Chart.bundle.min.js"></script>

	<!-- DataTables -->
	<script src="<?php echo base_url(); ?>assets/dashboard/assets/js/lib/data-table/datatables.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/dashboard/assets/js/lib/data-table/dataTables.bootstrap.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/dashboard/assets/js/lib/data-table/dataTables.buttons.min.js"></script>
	<script src="<?php echo base_url(); ?>assets/dashboard/plugins/iCheck/icheck.min.js"></script>

	<script src="<?php echo base_url('assets/common/'); ?>rateit/jquery.rateit.min.js"></script>

	<script src="//code.jquery.com/ui/1.12.1/jquery-ui.js"></script>
	<script src="<?php echo base_url('/'); ?>assets/dashboard/custom/custom.js"></script>

	<script src="<?php echo base_url(); ?>assets/dashboard/assets/js/lib/data-table/datatables-init.js"></script>
	<script>
	</script>
</body>
</html>