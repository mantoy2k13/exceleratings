<?php $this->load->view('dashboard/header'); ?>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    
    <!-- Main content -->
    <section class="content">
			<?php $this->load->view('dashboard/rev-question-list'); ?>
        <div class="box-footer">
          Footer
        </div>
        <!-- /.box-footer-->

    </section>

  </div>
  <!-- /.content-wrapper -->
  

  
<?php $this->load->view('dashboard/footer'); ?>

			